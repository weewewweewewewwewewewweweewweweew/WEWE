/*
 *  Chaturbate plugin for Movian Media Center
 *
 *  Copyright (C) 2015-2018 lprot
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

var page = require('showtime/page');
var service = require('showtime/service');
var http = require('showtime/http');
var io = require('native/io');
var plugin = JSON.parse(Plugin.manifest);
var logo = Plugin.path + plugin.icon;

RichText = function(x) {
    this.str = x.toString();
}

RichText.prototype.toRichString = function(x) {
    return this.str;
}

var BASE_URL = 'https://xhamster.com',
    UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36';

function setPageHeader(page, title) {
    page.type = "directory";
    page.contents = "items";
    page.metadata.logo = logo;
    page.metadata.title = new RichText(title);
}

var blue = '6699CC', orange = 'FFA500', red = 'EE0000', green = '008B45';
function coloredStr(str, color) {
    return '<font color="' + color + '">' + str + '</font>';
}

function trim(s) {
    if (s) return s.replace(/(\r\n|\n|\r)/gm, "").replace(/(^\s*)|(\s*$)/gi, "").replace(/[ ]{2,}/gi, " ").replace(/\t/g, '');
    return '';
}

service.create(plugin.title, plugin.id + ":start", 'tv', true, logo);

new page.Route(plugin.id + ":selectResolution:(.*):(.*)", function(page, url, title) {
    setPageHeader(page, unescape(title));
    page.loading = true;
	
    //var html = http.request('https://xhamster.com/video-hls/m3u8/' + url + '/a.m3u8?cdn_type=adv').toString();
	var html = http.request('https://xhamster.com/video-hls/m3u8/' + url + '/a.m3u8?cdn_type=adv', {headers: {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_2) AppleWebKit/604.4.7 (KHTML, like Gecko) Version/11.0.2 Safari/604.4.7'}}).toString();
	html=html.replace((/\\u002D/g),'-');
	var re=/NAME="([\s\S]*?)"([\s\S]*?mp4)/g;
	
	var match=re.exec(html);
	
    while (match) {
        page.appendItem(plugin.id + ":play:" + escape(match[2].trim()) + ':' + title, "video", {		// урл до playlist.mp38+
            title: match[1]
        });
		
        match = re.exec(html);
    }
    page.loading = false;
});


new page.Route(plugin.id + ":play:(.*):(.*)", function(page, url, title) {
    page.type = 'video';
    page.source = "videoparams:" + JSON.stringify({
        title: unescape(title),
        sources: [{
            url: unescape(url)
        }],
        no_subtitle_scan: true
    });
    page.loading = false;
});

new page.Route(plugin.id + ":index:(.*):(.*)", function(page, url, title) {
    setPageHeader(page, unescape(title));
	 page.loading = true;
	
    var url = url;
	

    tryToSearch = true;
    
	var re3=/<a class="video-thumb__image-container thumb-image-container" href="([\s\S]*?)"[\s\S]*?thumb-image-container__image" src="([\s\S]*?)"[\s\S]*?alt="([\s\S]*?)"[\s\S]*?duration">([\s\S]*?)<[\s\S]*?text">([\s\S]*?)</gm;
	
	// 1-link, 2-icon, 3-description, 4-duration, 5-stats.6 -votes
	
	  

        //if (!tryToSearch) return false;
       
        //var doc = http.request(url).toString();
		var doc = http.request(url, {headers: {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_2) AppleWebKit/604.4.7 (KHTML, like Gecko) Version/11.0.2 Safari/604.4.7'}}).toString();
		
		//scrapeItems(doc);
		var match3 = re3.exec(doc);
		 while (match3) {
            
            page.appendItem(plugin.id + ":selectResolution:" + match3[1].match(/[\d]{8}/g) + ':' + escape(match3[3]), "video", {
                title: new RichText(match3[3].trim() + ' ' + coloredStr(match3[4], orange) + ' ('  + ' ' + match3[5] + ') '),
                icon: match3[2],
                description: new RichText(coloredStr('Description: ', orange) + match3[3] + coloredStr('\nDuration: ', orange) + match3[4] +(match3[5] ? coloredStr('\nStats: ', orange) + match3[5] : null)),
				
            });
			
            match3 = re3.exec(doc);
        }
		
        page.loading = false;
		
       //var end = doc.indexOf('<li class="previous xh-paginator-hidden">');
       //if (end == -1)
       //    end = doc.indexOf(' <div class=" width-wrap">');
       //var blob = doc.substr(doc.indexOf(' <div class="mixed-section index-videos dated-list" data-role="index-recent-container">'), end);
		//console.log(blob);
       
            
        
        var next = doc.match(/<a href="([^"]*)" class="next endless_page_link"/);
        if (!next) return tryToSearch = false;
        url = BASE_URL + next[1];
		console.log(next);
        return true;
    
    
    page.paginator = loader;
    page.loading = false;
}); 

new page.Route(plugin.id + ":start", function(page) {
    setPageHeader(page, plugin.title);
    page.loading = true;
    io.httpInspectorCreate('.*chaturbate\\.com', function(req) {
        req.setHeader('User-Agent', UA);
    });

    io.httpInspectorCreate('.*chaturbate\\.com.*', function(req) {
        req.setHeader('User-Agent', UA);
    });

    //var doc = http.request('https://xhamster.com').toString();
	var doc = http.request('https://xhamster.com', {headers: {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_2) AppleWebKit/604.4.7 (KHTML, like Gecko) Version/11.0.2 Safari/604.4.7'}}).toString();
	
    // 1-section title, 2-block of links
    var re = /<div class="line"><\/div>[\s\S]*?<div class="all-categories">/gm;
    // 1-link, title
    var re2 = /a href="([\s\S]*?)"[\s\S]*?i>([\s\S]*?)</g;
	//var re2 =/https:\/\/xhamster/g;
    var match = re.exec(doc);
	
    while (match) {
        
        var match2 = re2.exec(match);
		console.log(match2);
        while (match2) {
            page.appendItem(plugin.id + ":index:" + match2[1] + ':' + escape(match2[2].trim()), "directory", {
                title: match2[2].trim()
	    });
		//console.log(plugin.id + ":index:" + match2[1] + ':' + escape(match2[2]));
            match2 = re2.exec(match);
        }
        match = re.exec(doc);
    }
	 var re = /<div class="all-categories">[\s\S]*?<li class="list-title">Channels/gm;
    // 1-link, title
    var re2 = /a href="([\s\S]*?)"[\s\S]*?>([\s\S]*?)</g;
	//var re2 =/https:\/\/xhamster/g;
    var match = re.exec(doc);
	
    while (match) {
        
        var match2 = re2.exec(match);
		console.log(match2);
        while (match2) {
            page.appendItem(plugin.id + ":index:" + match2[1] + ':' + escape(match2[2].trim()), "directory", {
                title: match2[2].trim()
	    });
		//console.log(plugin.id + ":index:" + match2[1] + ':' + escape(match2[2]));
            match2 = re2.exec(match);
        }
        match = re.exec(doc);
    }
	
    page.loading = false;
	
});
