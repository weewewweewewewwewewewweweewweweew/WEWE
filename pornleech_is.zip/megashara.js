﻿/**
 * rutor.org plugin for Movian Media Center
 *  Copyright (C) 2015 lprot
 *  You should have received a copy of the GNU General Public License
 *  along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
(function(plugin) {

    var logo = plugin.path + "logo.png";

    var blue = '6699CC',
        orange = 'FFA500',
        red = 'EE0000',
        green = '66ff72';

    function cleanStr(str) {
        return str.replace(/<[^>]+>/g, '').trim();
    }

    function colorStr(str, color) {
        return '<font color="' + color + '"> (' + str + ')</font>';
    }

    function coloredStr(str, color) {
        return '<font color="' + color + '">' + str + '</font>';
    }

    function setPageHeader(page, title) {
        if (page.metadata) {
            page.metadata.title = title;
            page.metadata.logo = logo;
        }
        page.type = "directory";
        page.contents = "items";
        page.loading = false;
    }

    var tags=[];
    function extractTags(doc){
        if(tags.length!=0){
            return doc;
        }
        var re = /&amp;genre=(\d+)">([^<]+)<\/a>/g;
        var m=re.exec(doc);
        while(m){
            tags.push({v:m[1],t:m[2]});
            m = re.exec(doc);
        }
        return doc;
    }


    var service = plugin.createService(plugin.getDescriptor().title, plugin.getDescriptor().id + ":start", "video", true, logo);

    var settings = plugin.createSettings(plugin.getDescriptor().title, logo, plugin.getDescriptor().synopsis);

    settings.createString('baseURL', "Base URL without '/' at the end.", 'http://pornleech.is', function(v) {
        service.baseURL = v;
    });

    function list(page, doc) {
        var re = /<tr>\s*<td[^>]+class="lista"[^>]+><a[^>]+><img[^>]+?title="([^"]+)"[^>]+>[\s\S]+?className=[^>]+><a\s+href="[^"]+?\-(\d+)\.html"[^>]+?src=torrentimg\/(\w{40})\.(\w+)[^>]+>[^>]+>([^<]+)<[\s\S]+?text-align:center;">([^<]+)<[\s\S]+?<td[\s\S]+?<td[^>]+>([^<]+)[\s\S]+?-->[\s\S]+?:green;[^>]+>(\d+)<[\s\S]+?:red;[^>]+>(\d+)</g;
        var n =0;
        //1 type 2 id 3 title
        var match = re.exec(doc);
        while (match) {
            var licon = service.baseURL + '/torrentimg/' + match[3] + '.' + match[4];
            page.appendItem(plugin.getDescriptor().id + ':list:' + match[2], "directory", {
                title: new showtime.RichText(colorStr(match[6].trim().substr(0,10), orange) + ' ' + match[5] + ' ' + coloredStr(match[8], green) + '/' + coloredStr(match[9], red) + ' ' + colorStr(match[7], blue)),
                icon: licon
            });
            page.entries++;
            n++;
            match = re.exec(doc);
        }
        return n;
    }


    function scraper(page, doc, id) {
        var rePage=/class="block-head-title">([^<]+)<[\s\S]+?download\.php\?id=(\w{40})&[\s\S]+?color:green;'>(\d+)<[\s\S]+?color:red;'>(\d+)<[\s\S]+?src="(torrentimg\/[^"]+)"[\s\S]+?class="header">Size<[^>]+>\s*<[^>]+>([^<]+)<[\s\S]+?class="header">AddDate<[^>]+>\s*<[^>]+>([^<]+)</g;
        // 1 type 2 id 3 name 4 magnet 5 size 6 date 7 seed 8 leech
        var m = rePage.exec(doc);
        page.metadata.glwview = plugin.path + "list.view";

        page.appendItem('torrent:browse:' + service.baseURL + '/download.php?id=' + m[2] +'&f=1.torrent', 'video', {
            title: new showtime.RichText(m[1]),
            icon: service.baseURL + '/' + m[5],
            //backdrops: backdrops,
            //source: source ? new RichText('Добавил: ' + coloredStr(source, orange)) : void(0),
            genre: new showtime.RichText(//genre +
                'Раздают: ' + coloredStr(m[3], green) +
                ' Качают: ' + coloredStr(m[4], red) +
                '<br>Размер: ' + coloredStr(m[6], blue) + 
                ' Добавлен: ' + coloredStr(m[7], orange)
                ),
            //rating: raiting ? 10 * raiting : void(0),
            //tagline: new showtime.RichText(coloredStr('Добавлен: ', orange) + m[7]),
            //description: description ? new RichText(description) : void(0)
        });    
    }

    function listPage(page, url, title, cb) {
        setPageHeader(page, title);
        page.entries = 0;
        var fromPage = 0,
            tryToSearch = true;

        var loader = function(){
            if (!tryToSearch) return false;
            page.loading = true;
            var doc = showtime.httpReq(service.baseURL + url + fromPage ).toString();
            page.loading = false;
            if(cb) cb(page, fromPage, doc);
            var n = list(page, doc);
            if (n==0) return tryToSearch = false;
            fromPage++;
            return true;
        };

        loader();
        page.paginator = loader;
    }


    var startUrl = '/index.php?page=torrents&search=&options=0&active=0&category=64%3B65%3B66%3B70%3B77';

    plugin.addURI(plugin.getDescriptor().id + ":category:(.*):(.*)", function(page, url, name) {
        setPageHeader(page, plugin.getDescriptor().synopsis);
        name = unescape(name);
        listPage(page,  startUrl+'&genre='+url+'&pages=', name)
    });

    plugin.addURI(plugin.getDescriptor().id + ":list:(.*)", function(page, url) {
        setPageHeader(page, plugin.getDescriptor().synopsis);
        page.loading = true;
        var url1 = service.baseURL + '/nwn3s8zn-' + url + '.html';
        var doc = showtime.httpReq(url1).toString();
        scraper(page, doc, url);
        page.loading = false;
    });

    function fillStart(page,doc){
        extractTags(doc);
        page.appendItem(plugin.getDescriptor().id + ":categories:", 'directory', {
            title: 'Категории'
        });

        page.appendItem("", "separator", {
            title: ''
        });    
    }

    plugin.addURI(plugin.getDescriptor().id + ":start", function(page) {
        listPage(page, startUrl + '&pages=', plugin.getDescriptor().synopsis, function(page,n,doc){
            if(n!==0) return;
            page.appendItem(plugin.getDescriptor().id + ":search:", 'search', {
                title: 'Поиск на ' + service.baseURL
            });
            fillStart(page,doc);
        });
    });

    plugin.addURI(plugin.getDescriptor().id + ":categories:", function(page) {
        setPageHeader(page, 'Категории -' + plugin.getDescriptor().title);
        page.loading = true;
        if(0==tags.length)
            extractTags(showtime.httpReq(service.baseURL + startUrl).toString());
        for(var i=0;i<tags.length;i++){
            page.appendItem(plugin.getDescriptor().id + ':category:' + tags[i].v + ':' + escape(tags[i].t), 'directory', {
                title: tags[i].t
            });
        }
        page.loading = false;
    });

    function search(page, query) {
        listPage(page, startUrl.split('&search=&').join( '&search=' + encodeURIComponent(query) + '&')+'&pages=', 
            plugin.getDescriptor().title);
    }

    plugin.addURI(plugin.getDescriptor().id + ":search:(.*)", function(page, query) {
        search(page, query);
    });

    plugin.addSearcher(plugin.getDescriptor().id, logo, function(page, query) {
        search(page,query);
    });    

})(this);