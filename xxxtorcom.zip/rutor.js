/**
 * Rutor plugin for Movian Media Center
 *
 *  Copyright (C) 2015-2018 lprot
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

var page = require('showtime/page');
var service = require('showtime/service');
var settings = require('showtime/settings');
var http = require('showtime/http');
var plugin = JSON.parse(Plugin.manifest);
var logo = Plugin.path + plugin.icon;

var tags=[];
function extractTags(doc){
	if(tags.length!=0)
		return doc;
	var re = /<li><a\s+href="[^"]*?\/tag\/(\d+)-[^"]+">([^<]+)</g;
	var m=re.exec(doc);
	while(m){
		tags.push({v:m[1],t:m[2]});
		m = re.exec(doc);
	}
	return doc;
}

RichText = function(x) {
	this.str = x.toString().split(' & ').join(' &amp; ');
}


RichText.prototype.toRichString = function(x) {
	return this.str;
}

var blue = '6699CC', orange = 'FFA500', red = 'EE0000', green = '008B45';
function colorStr(str, color) {
	return '<font color="' + color + '"> (' + str + ')</font>';
}

function coloredStr(str, color) {
	return '<font color="' + color + '">' + str + '</font>';
}

function setPageHeader(page, title) {
	if (page.metadata) {
		page.metadata.title = new RichText(title);
		page.metadata.logo = logo;
	}
	page.type = "directory";
	page.contents = "items";
	page.loading = false;
}

service.create(plugin.title, plugin.id + ":start", 'video', true, logo);

settings.globalSettings(plugin.id, plugin.title, logo, plugin.synopsis);
settings.createString('baseURL', "Base URL without '/' at the end", 'http://xxxtor.com', function(v) {
	service.baseURL = v;
});

new page.Route(plugin.id + ":indexImages:(.*):(.*)", function(page, torrentId, title) {
	page.model.contents = 'grid';
	setPageHeader(page, unescape(title));
	page.loading = true;
	var doc = http.request(service.baseURL + '/torrent/' + torrentId +'/').toString();
	try {
		doc = doc.match(/<table id="details">([\s\S]*?)<td class='header'>Оценка</)[1];
		var re = /<img[^><]+?src=["']([^"']+?)['"]/g;
		var match = re.exec(doc);
		while (match) {
			page.appendItem(match[1], 'image'); 
			match = re.exec(doc);
		}
	} catch(err) {}
	page.loading = false;
});

new page.Route(plugin.id + ":indexItem:(.*):(.*)", function(page, torrentId , title) {
	setPageHeader(page, unescape(title));
	page.loading = true;
	var doc = http.request(service.baseURL + '/torrent/' + torrentId +'/').toString();
	var icon = description = void(0);

	var details = doc.match(/<table id="details">([\s\S]*?)<\/table>/);
	if(details){
		details = details[1];
		icon = details.match(/<img[^><]+?src=["']([^"']+?)['"]/);
		if(icon) icon=icon[1];
		var expressions = [/О фильме:[\S\s]*?>([\S\s]*?)<a/, /Описание:[\S\s]*?>([\S\s]*?)<a/, /Описание[\S\s]*?>([\S\s]*?)<a/,
			/О сериале:[\S\s]*?>([\S\s]*?)<a/, /О фильме[\S\s]*?>([\S\s]*?)<a/, /Содержание:[\S\s]*?>([\S\s]*?)<a/];
		for (var i = 0 ; i < expressions.length; i++) {
			description = details.match(expressions[i]);
			if (description) {
				description = description[1].replace(/<br[^>\/]*\/?>/g, ' ').trim();
				break;
			}
		}
	}

	page.metadata.logo = icon;

	var source = doc.match(/<td class='header'>Залил<\/td>[\S\s]*?">([\S\s]*?)<\/a>/);
	if(source) source=source[1];

	var raiting = doc.match(/<td class='header'>Оценка<\/td><td>([\S\s]*?) из/);
	if(raiting) raiting=raiting[1];

	var screenshots = doc.match(/Скриншоты([\S\s]*?)(<\/textarea>|<td class='header'>)/);
	if(screenshots) screenshots=screenshots[1];
	var backdrops = [];
	if (screenshots) {
		var re = /<img[^><]+?src=["']([^"']+?)['"]/g;
		match = re.exec(screenshots);
		while (match) {
			backdrops.push({url: match[1]});
			match = re.exec(screenshots);
		}
	}

	var genre = doc.match(/<td class='header'>Категория<[\S\s]*?>([^><]+?)</);
	if(genre) genre=genre[1];

	var seeders = doc.match(/<td class='header'>Раздают<\/td><td>([\S\s]*?)<\/td>/);
	if(seeders) seeders=seeders[1];

	var leechers = doc.match(/<td class='header'>Качают<\/td><td>([\S\s]*?)<\/td>/);
	if(leechers) leechers=leechers[1];

	var size = doc.match(/<td class='header'>Размер<\/td><td>([\S\s]*?)<\/td>/);
	if(size) size=size[1];

	var dt = doc.match(/<td class='header'>Добавлен<\/td><td>([\S\s]*?)<\/td>/);
	if(dt) dt=dt[1];

	page.appendItem('torrent:browse:' + service.baseURL + '/download/' + torrentId +'/', 'video', {
		title: new RichText(unescape(title)),
		icon: icon,
		backdrops: backdrops,
		source: source ? new RichText('Добавил: ' + coloredStr(source, orange)) : void(0),
		genre: new RichText(genre +
			'<br>Раздают: ' + coloredStr(seeders, green) +
			' Качают: ' + coloredStr(leechers, red) +
			'<br>Размер: ' + size),
		rating: raiting ? 10 * raiting : void(0),
		tagline: new RichText(coloredStr('Добавлен: ', orange) + dt),
		description: description ? new RichText(description) : void(0)
	});
	if (icon)
		page.appendItem(plugin.id + ':indexImages:' + torrentId + ':' + title, 'directory', {
			title: 'Картинки',
			icon: icon
		}); 
	page.loading = false;
});

function scraper(page, doc, section) {
	var re2 =/<tr\s+class="(?:gai|tum)+"><td>([^<]+)<\/td>[\s\S]+?\/torrent\/(\d+)\/">([^<]+)<\/a>[\s\S]+?&nbsp;(\d+)<\/span[\s\S]+?&nbsp;(\d+)<\/span[\s\S]+?align="right">([^<]+)</g;
	var j=0;
	var match = re2.exec(doc);
	while (match) {
		j++;
		page.appendItem(plugin.id + ':indexItem:' + match[2] + ':' + escape(match[3]), 'directory', {
			title: new RichText(colorStr(match[1], orange) + ' ' +
				match[3] + ' ('+ coloredStr(match[4], green) + '/'+
				coloredStr(match[5], red) + ') ' + colorStr(match[6], blue) )
		}); 
		page.entries++;
		match = re2.exec(doc);
	}
	return j;
}

function browse(page, url, title, n) {
	setPageHeader(page, plugin.synopsis + ' / ' + title);
	page.loading = true;
	page.entries = 0;
	var tryToSearch = true, fromPage=0;
	function loader() {
		if (!tryToSearch) return false;
		page.loading = true;
		var doc = http.request(service.baseURL + url.split('@').join(fromPage)).toString();
		page.loading = false;
		var more = scraper(page, doc);
		if (!more) return tryToSearch = false;
		fromPage += n;
		return true;
	};
	loader();
	page.paginator = loader;
}


new page.Route(plugin.id + ":browse:(.*):(.*)", function(page, url, title) {
	browse(page, url, unescape(title), 100);
});

new page.Route(plugin.id + ":categories", function(page) {
	setPageHeader(page, plugin.title + ' - Категории');
	page.loading = true;
	if (tags.length==0) 
		extractTags(http.request(service.baseURL + '/').toString());
	for(var i=0;i<tags.length;i++){
		page.appendItem(plugin.id + ':browse:/tag/' + tags[i].v + '/page/@/sort/0:' + escape(tags[i].t), 'directory', {
			title: tags[i].t
		});
	}
	page.loading = false;
});

new page.Route(plugin.id + ":start", function(page) {
	setPageHeader(page, plugin.synopsis);
	page.loading = true;

	page.appendItem(plugin.id + ":search:", 'search', {
		title: 'Поиск на ' + service.baseURL
	});

	var doc = extractTags(http.request(service.baseURL + '/').toString());

	page.appendItem(plugin.id + ":categories:", 'directory', {
		title: 'Категории'
	});

	page.appendItem("", "separator", {
		title: ''
	});

	scraper(page, doc);

	page.loading = false;
});

function search(page, query) {
	browse(page, '/b.php?search=' + encodeURIComponent(query) + '&page=@&cat=0', 'Поиск "' + query + '"', 1);
}

new page.Route(plugin.id + ":search:(.*)", function(page, query) {
	search(page, query);
});

page.Searcher(plugin.id, logo, function(page, query) {
	search(page, query);
});
