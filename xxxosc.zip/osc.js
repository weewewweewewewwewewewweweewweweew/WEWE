﻿/**
 * rutor.org plugin for Movian Media Center
 *  Copyright (C) 2015 lprot
 *  You should have received a copy of the GNU General Public License
 *  along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
(function(plugin) {
    //var reList=/<tr>\s*<td\s+class=ttable_col1[^>]*>\s*<a[^>]*>\s*<img.*?src="([^"]+)"\s+alt="([^"]+)".*?<\/a><\/td>\s*<td.*?<a\s+title="([^"]+)"\s*href="torrents-details\.php\?id=(\d+).*?<td[^>]*><a[^>]*><img[^>]*><\/a><\/td><td[^>]*><a[^>]*><img[^>]*><\/a><\/td><td[^>]*>([^<]+)<\/td>\s*<td[^>]*><b><font\s*color=green><B>(\d+)<\/b><\/font><\/td>\s*<td[^>]*><font\s*color=red><B>(\d+)<\/b>/gu;
    // 1 icon 2 catname 3 title 4 id 5 size 6 seeders 7 leechers
    //var rePage=/class="fcapbar"[^>]*><b>([^<]+)<[\S\s]*?<B>Сидеры:\s*<\/b>\s*<font color=green>(\d+)<[\S\s]*?<B>Личеры:\s*<\/b>\s*<font color=red>(\d+)<[\S\s]*?<B>Последнее Обновление:\s*<\/b>([^<]+)<[\S\s]+?<img\s*align='right'\s*"border='0'\s*src='([^']+)'[\S\s]*?align=left><b>Общий размер:<\/b><\/td><td>([^<]+)</gu;
    // 1 name 2 seeders 3 leechers 4 date 5 image 6 size



    var logo = plugin.path + "logo.png";

    var blue = '6699CC',
        orange = 'FFA500',
        red = 'EE0000',
        green = '66ff72';

    function cleanStr(str) {
        return str.replace(/<[^>]+>/g, '').trim();
    }

    function colorStr(str, color) {
        return '<font color="' + color + '"> (' + str + ')</font>';
    }

    function coloredStr(str, color) {
        return '<font color="' + color + '">' + str + '</font>';
    }

    function setPageHeader(page, title) {
        if (page.metadata) {
            page.metadata.title = title;
            page.metadata.logo = logo;
        }
        page.type = "directory";
        page.contents = "items";
        page.loading = false;
    }

    var service = plugin.createService(plugin.getDescriptor().title, plugin.getDescriptor().id + ":start", "video", true, logo);

    var settings = plugin.createSettings(plugin.getDescriptor().title, logo, plugin.getDescriptor().synopsis);

    settings.createString('baseURL', "Base URL without '/' at the end.", 'http://open-sharing.com', function(v) {
        service.baseURL = v;
    });

    function list(page, doc) {
        var n =0;
        // 1-date, 2-filelink, 3-infolink, 4-title, 5-(1)size, (2)seeds, (3)peers
        var re=/<tr>\s*<td\s+class=ttable_col1[^>]*>\s*<a[^>]*>\s*<img.*?src="([^"]+)"\s+alt="([^"]+)".*?<\/a><\/td>\s*<td.*?<a\s+title="([^"]+)"\s*href="torrents-details\.php\?id=(\d+).*?<td[^>]*><a[^>]*><img[^>]*><\/a><\/td><td[^>]*><a[^>]*><img[^>]*><\/a><\/td><td[^>]*>([^<]+)<\/td>\s*<td[^>]*><b><font\s*color=green><B>(\d+)<\/b><\/font><\/td>\s*<td[^>]*><font\s*color=red><B>(\d+)<\/b>/g;
        // 1 icon 2 catname 3 title 4 id 5 size 6 seeders 7 leechers
        var match = re.exec(doc);
        while (match) {
            var url = match[4];
            var licon = match[1];
            page.appendItem(plugin.getDescriptor().id + ':list:' + url, "directory", {
                title: new showtime.RichText(colorStr(match[2], orange) + ' ' + match[3] + ' ' + coloredStr(match[6], green) + '/' + coloredStr(match[7], red) + ' ' + colorStr(match[5], blue)),
                icon: licon
            });
            page.entries++;
            n++;
            match = re.exec(doc);
        }
        return n;
    }



    function scraper(page, doc, id) {
        // 1-date, 2-filelink, 3-infolink, 4-title, 5-(1)size, (2)seeds, (3)peers
        //var head = /::([\s\S]*?)<\/title[\s\S]*?<[\s\S]*?mail[\s\S]*?a href="([\s\S]*?)"[\s\S]*?/g;
        page.metadata.glwview = plugin.path + "list.view";
        var obj = {
            downurl: service.baseURL + '/download.php?id='+id+'&name='+id,
            downtext: "torrent #" +id,
            title: "torrent #" +id,
            logo: plugin.path + "logo.png"
        } ;
         

        var rePage=/class="fcapbar"[^>]*><b>([^<]+)<[\S\s]*?<B>Сидеры:\s*<\/b>\s*<font color=green>(\d+)<[\S\s]*?<B>Личеры:\s*<\/b>\s*<font color=red>(\d+)<[\S\s]*?<B>Последнее Обновление:\s*<\/b>([^<]+)<[\S\s]+?<img\s*align='right'\s*"border='0'\s*src='([^']+)'[\S\s]*?align=left><b>Общий размер:<\/b><\/td><td>([^<]+)</g;
        // 1 name 2 seeders 3 leechers 4 date 5 image 6 size

        var match = rePage.exec(doc);
        if(match){
            obj.downtext = '' + match[2] + ' / ' + match[3] + ' ('+ match[6] + ') ' + match[4];
            obj.title = match[1];
            obj.logo = match[5]; 
        }




        page.metadata.title = obj.title;
        page.metadata.logo = obj.logo;



        var arr = [
        	{u:'torrent:browse:' + obj.downurl ,n:obj.downtext},
//        	{u:rx(/href="(magnet:[^"]+)"/,doc,1),n:'magnet'},
//        	{u:rx(/href="(magnet:[^"&]+)/,doc,1) + '&tr=udp%3A%2F%2Fopentor.org%3A2710&tr=http%3A%2F%2Fxbtrutor.com%3A2710%2Fannounce&tr=http%3A%2F%2Fbt.rutor.org%3A444%2Fannounce&tr=udp%3A//tracker.leechers-paradise.org%3A6969&tr=udp%3A//tracker.coppersurfer.tk%3A6969&tr=udp%3A//shubt.net%3A2710&tr=http%3A//p4p.arenabg.ch%3A1337/announcee&tr=udp%3A//tracker.opentrackr.org%3A1337&tr=udp%3A//explodie.org%3A6969&tr=udp%3A//tracker.zer0day.to%3A1337',n:'magnet'},
        ];

        for(var j=0; j<arr.length; j++){
            var url = arr[j].u;
            page.appendItem(url, "video", {
                title: arr[j].n,
                description: obj.title,
                icon: obj.logo
            });

            page.entries++;
        }
    }

    function listPage(page, url, title) {
        setPageHeader(page, title);
        page.entries = 0;
        var fromPage = 0,
            tryToSearch = true;

        var loader = function(){
            if (!tryToSearch) return false;
            page.loading = true;
            var doc = showtime.httpReq(service.baseURL + url + fromPage ).toString();
            page.loading = false;
            var n = list(page, doc);
            if (n==0) return tryToSearch = false;
            fromPage++;
            return true;
        };

        loader();
        page.paginator = loader;
    }



    plugin.addURI(plugin.getDescriptor().id + ":category:(.*):(.*)", function(page, url, name) {
        setPageHeader(page, plugin.getDescriptor().synopsis);
        name = decodeURIComponent(name);
        listPage(page, url, name)
    });

    plugin.addURI(plugin.getDescriptor().id + ":list:(.*)", function(page, url) {
        setPageHeader(page, plugin.getDescriptor().synopsis);
        page.loading = true;
        var url1 = service.baseURL + '/torrents-details.php?id=' + url
        var doc = showtime.httpReq(url1).toString();
        scraper(page, doc, url);
        page.loading = false;
    });


    plugin.addURI(plugin.getDescriptor().id + ":start", function(page) {
        setPageHeader(page, plugin.getDescriptor().synopsis);
        page.appendItem(plugin.getDescriptor().id + ":search:", 'search', {
            title: 'Поиск на ' + service.baseURL
        });

        var arrow = plugin.path + "arrow.png";
        page.appendItem("", "separator", {
            title: ''
        });
        //Pages: browse, recent, tv shows, Music, Top 100
        var pages = [
                {"url": '/torrents-search.php?sort=id&order=desc&page=',"name": 'Новые'},
                {"url":"/torrents.php?cat=5000&page=","name":"Animation - Cartoon"},
                {"url":"/torrents.php?cat=225&page=","name":"Animation - Hentai"},
                {"url":"/torrents.php?cat=145&page=","name":"Misc & Other - Documentary"},
                {"url":"/torrents.php?cat=245&page=","name":"Misc & Other - Video Pack"},
                {"url":"/torrents.php?cat=440&page=","name":"Misc & Other - Images & Wallpaper"},
                {"url":"/torrents.php?cat=1&page=","name":"Movies XXX - Asian"},
                {"url":"/torrents.php?cat=20&page=","name":"Movies XXX - Amateur"},
                {"url":"/torrents.php?cat=40&page=","name":"Movies XXX - Anal & DP"},
                {"url":"/torrents.php?cat=60&page=","name":"Movies XXX - BDSM"},
                {"url":"/torrents.php?cat=80&page=","name":"Movies XXX - Boobs"},
                {"url":"/torrents.php?cat=100&page=","name":"Movies XXX - Classic & Feature"},
                {"url":"/torrents.php?cat=120&page=","name":"Movies XXX - Compilation"},
                {"url":"/torrents.php?cat=140&page=","name":"Movies XXX - Casting"},
                {"url":"/torrents.php?cat=150&page=","name":"Movies XXX - Erotic"},
                {"url":"/torrents.php?cat=180&page=","name":"Movies XXX - Fetish"},
                {"url":"/torrents.php?cat=200&page=","name":"Movies XXX - Gonzo"},
                {"url":"/torrents.php?cat=220&page=","name":"Movies XXX - Group & GangBang"},
                {"url":"/torrents.php?cat=240&page=","name":"Movies XXX - Interracial"},
                {"url":"/torrents.php?cat=260&page=","name":"Movies XXX - Latin & Black"},
                {"url":"/torrents.php?cat=280&page=","name":"Movies XXX - Lesbian"},
                {"url":"/torrents.php?cat=300&page=","name":"Movies XXX - Young"},
                {"url":"/torrents.php?cat=320&page=","name":"Movies XXX - MILF & Mature"},
                {"url":"/torrents.php?cat=340&page=","name":"Movies XXX - Oral & Blowjob"},
                {"url":"/torrents.php?cat=360&page=","name":"Movies XXX - Parody"},
                {"url":"/torrents.php?cat=380&page=","name":"Movies XXX - Public & Reality"},
                {"url":"/torrents.php?cat=400&page=","name":"Movies XXX - Russian"},
                {"url":"/torrents.php?cat=425&page=","name":"Movies XXX - С Русским переводом!"}
            ],
            i, length = pages.length;
        setPageHeader(page, plugin.getDescriptor().synopsis);
        for (i = 0; i < length; i++) {

            page.appendItem(plugin.getDescriptor().id + ":category:" + pages[i].url + ':' + encodeURIComponent(pages[i].name), 
            	"directory", 
            	{
	                title: pages[i].name,
	                icon: arrow
            	}
            );

        }
        page.loading = false;
    });


    function search(page, query) {
        listPage(page,'/torrents-search.php?search=' + encodeURIComponent(query) + '&sort=id&order=desc&page=', plugin.getDescriptor().title);
    }

    plugin.addURI(plugin.getDescriptor().id + ":search:(.*)", function(page, query) {
        search(page, query);
    });

    plugin.addSearcher(plugin.getDescriptor().id, logo, function(page, query) {
    	search(page,query);
    });

})(this);